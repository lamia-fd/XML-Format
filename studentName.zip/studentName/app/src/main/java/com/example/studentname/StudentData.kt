package com.example.studentname

data class StudentData(val id:Int,val name:String,val marks:Int)