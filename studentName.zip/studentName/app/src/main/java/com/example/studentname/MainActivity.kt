package com.example.studentname

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var student: List<StudentData>
    var studentrv = ArrayList<String>()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rv=findViewById<RecyclerView>(R.id.recyclerView)
        rv.adapter = recycler(studentrv)
        rv.layoutManager = LinearLayoutManager(this)

        try{
            val parser = MyXmlPullParserHandler()
            val iStream = assets.open("student.xml")
            student = parser.parse(iStream)

            var text = ""
            for(s in student){
                text = """  ${s.name}  
                    |  ${s.marks} """.trimMargin()
                studentrv.add(text)
                rv.adapter?.notifyDataSetChanged()
            }


        }catch (e: IOException) {
            println("ISSUE: $e")
        }
    }
    }


